﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorldCupWF.UC;

namespace WorldCupWF.Interfaces
{
    public interface IDragable
    {
        void DragPlayer(PlayerUC playerUC);
    }
}
